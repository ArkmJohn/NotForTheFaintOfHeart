Sound pack downloaded from Freesound.org
----------------------------------------

This pack of sounds contains sounds by the following user:
 - MLGProPlayer ( https://www.freesound.org/people/MLGProPlayer/ )

You can find this pack online at: https://www.freesound.org/people/MLGProPlayer/packs/16637/

License details
---------------

Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 269346__mlgproplayer__i-see-you-3.wav
    * url: https://www.freesound.org/s/269346/
    * license: Attribution Noncommercial


